import React from 'react';

import ReactDOM from 'react-dom';

import {
  BrowserRouter as Router,
  Route
} from 'react-router-dom'
import { Link,Switch } from 'react-router-dom';

/*4.x introduced some breaking changes, you'll need to import Link from react-router-dom:*/

const Home = () => (<div><h1>Welcome home</h1><Link to='/about'>Go to about</Link></div>)
const About = () => (<div><h1>About</h1><Link to='/'>Go home</Link></div>)
  
class App extends React.Component {
  render() {
    return (
      <Router>
        <Switch>
          <Route path="/about" component={About} />
          <Route exact={true} path="/" component={Home} />
        </Switch>
      </Router>
    )
  }
}
export default App;


