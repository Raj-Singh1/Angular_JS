import React from 'react';

import ReactDOM from 'react-dom';

import Head from './Head';

class PropsProb extends React.Component {
  render() {
		console.log(this.props.appName)
	return(
		<div>
			<h1>content of PropsProb component</h1>
			<Head appName={this.props.appName}/>
		</div>
	);   
  }
}
export default PropsProb;


