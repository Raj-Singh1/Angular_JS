import React from 'react';

import ReactDOM from 'react-dom';

import Title from './Title';

class Head extends React.Component {
  render() {
	return(
		<div>
			<h1>content of head component</h1>
			<Title appName={this.props.appName}/>
		</div>
	);   
  }
}
export default Head;


