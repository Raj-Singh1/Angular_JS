import React from 'react';

import ReactDOM from 'react-dom';


import ParentComponent from './ParentComponent';



ReactDOM.render(<staticMethod num1={10} num2={23}/>, document.getElementById('root'));
