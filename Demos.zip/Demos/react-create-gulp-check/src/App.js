import React from 'react';

import ReactDOM from 'react-dom';

import Greeting from './GreetingConditionalRendering';

React.render(<Parent />, document.getElementById('app'));
