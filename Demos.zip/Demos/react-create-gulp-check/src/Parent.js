//var React = require('react');
//var ReactDOM = require('react-dom');
var Parent = React.createClass({
  render: function(){
    return (
      <div>
        <div> This is the parent. </div>
        <Child name="child"/>
      </div>
    )
  }
});
//export default Greeting;


