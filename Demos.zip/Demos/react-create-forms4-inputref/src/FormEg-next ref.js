import React from 'react';

import ReactDOM from 'react-dom';


class AddCityName extends React.Component {
	constructor()
	{
		super();
		this.state={
		value:'',
		items:[]
		}
	}
	handleInputChange=(event)=>{
	console.log('evt',event.target.value);
		this.setState({
			value: event.target.value
		});
	}
	addCity=(event)=>{
	event.preventDefault();//no navigation should happen
	const arr= this.state.items.slice();
	arr.push(this.refs.newItem.value);
	//set state for originaal array
	
	this.setState({
		items:arr,
		value:''
	});
	}
	render(){
        return(
	<div>
            <form id="add-city" onSubmit={this.addCity.bind(this)}>
                <input type="text" required ref="newItem" onChange={this.handleInputChange}/> 
                <input type="submit" value="Add City" />
            </form>
		<ul>
	{this.state.items.map((item,index)=> <li key={index}>{item}</li>)}
	</ul>
</div>

        );
    }

    //Custom functions
    addCity(e){
        e.preventDefault();
	console.log(this.refs.newItem.value);
       // this.props.onAdd(this.refs.newItem.value);
    }
}

export default AddCityName;

