import React from 'react';

import ReactDOM from 'react-dom';

import Child from './Child'; 
class Parent extends React.Component {
	constructor(){
	super();
	this.state={ val:''};
		}	
	updateText(event){

		this.setState({val:event.target.value});
			}
	render(){
	     return(
		<div>
		<h1>React Unidirectional data flow</h1>
	<input type="text" onChange= {this.updateText.bind(this)}/>
	&nbsp;
	<Child data={this.state.val}/>
		</div>
			);
			}
}
export default Parent;


