import React from 'react';
import ReactDOM from 'react-dom';


import Title from './Title';
export default class Header extends React.Component {
 
	 render() {

//		console.log(this.props);
		console.log(this.props.tit);
		return(	
		<div>
		<Title /><header>this is Header</header>
		</div>
			);
		}
}

