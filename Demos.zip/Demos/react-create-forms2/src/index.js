import React from 'react';

import ReactDOM from 'react-dom';


import FormEg from './FormEg';




ReactDOM.render(<FormEg/>
	, document.getElementById('root'));



/*task : iterate by passing json data as products - iterate using foreach*/