import React from 'react';
import ReactDOM from 'react-dom';

//import './index.css';




// class App extends React.Component {
 
// 	 render() {
   
// 	 return React.createElement('div',null,'Hello!!!');
// 		}
// }
const e = React.createElement;

ReactDOM.render(
	<div className="app">Hello World</div>,
		document.getElementById('root'),
		()=>{
			console.log("callback called");		}
);


/*
const e = React.createElement;

ReactDOM.render(
  e('div', null, 'Hello World'),
  document.getElementById('root')
);
*/

