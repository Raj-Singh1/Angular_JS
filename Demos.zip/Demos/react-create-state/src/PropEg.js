import React from 'react';

import ReactDOM from 'react-dom';


class PropEg extends React.Component {
constructor()
	{
	super();
	this.state={country:['chennai','banglore','hyderabad']};
	} 
  render() {
		setTimeout(()=>{
const items = this.state.country;
console.log(items);
items[1]='bengaluru';
console.log(items[1]);
//this.state.country=items; 
this.setState({country:items});
//this.forceUpdate();
			},1000)
	return(
		<div>
			<p>countries are...</p>
				<ul>
				<li>{this.state.country[0]}</li>
				<li>{this.state.country[1]}</li>
				<li>{this.state.country[2]}</li>
				</ul>

		</div>
	);   
  }
}
export default PropEg;


