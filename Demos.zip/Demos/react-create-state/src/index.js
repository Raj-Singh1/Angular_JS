import React from 'react';

import ReactDOM from 'react-dom';


import PropEg from './PropEg';




ReactDOM.render(<PropEg/>
	, document.getElementById('root'));



/*task : iterate by passing json data as products - iterate using foreach*/