import React from 'react';

import ReactDOM from 'react-dom';


class ClickEvent extends React.Component {
	constructor(props)
	{
	super();
		this.state={
		count:props.intialValue,
		newCount:''
		}
	} 
	increase()
	{
	this.setState({
		newCount:this.state.count++
		});
		//console.log(newCount);
	}
	decrease()
	{
	this.setState({
		newCount:this.state.count--
		});

	}
  render() {
	return(
		<div>
		<h1>{this.state.newCount}</h1>
	<button type="submit" 
		onClick={this.increase.bind(this)}>Increase</button>
	<button type="submit" 
		onClick={this.decrease.bind(this)}>Decrease</button>
		</div>
	);   
  }
}
export default ClickEvent;
/*
<button type="submit" 
		onClick={this.increase.bind(this)}>Decrease</button>
if you generally use this.increase it refers to who triggers this event and not to class, if you use state then no problem, you set and get using state methods, but now we have refer to class instead of button
{ bind(this)-> refers to current class not button

<button type="submit" 
		onClick={()=>this.increase()	}>Decrease</button>
ES6 syntax instead of above ->  ()=>this.increase()

In the above code snippet nothing will always print 1 against no of clicks made, because the state is not set when event happens, only is printed in console, how will we print in browser using state?

*/

