import React from 'react';
import ReactDOM from 'react-dom';



var styles = {backgroundColor:'skyblue'};
var tested =prompt("enter true or false");

if(tested === true ){
        console.log(tested);
}

var reactNodeLi = <li id=""
                    
                     
                      className="blue"
                      aria-test="test"
                      style={styles}
                      foo="bar">
                          {tested === true ?<div>you entered true</div>:<div>you entered false</div>}
                  </li>;

ReactDOM.render(reactNodeLi, document.getElementById('root'));