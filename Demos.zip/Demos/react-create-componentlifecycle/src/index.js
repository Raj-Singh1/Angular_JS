import React from 'react';

import ReactDOM from 'react-dom';


import ClickEvent from './ClickEvent';




ReactDOM.render(<ClickEvent intialValue="1"/>
	, document.getElementById('root'));



/*task : iterate by passing json data as products - iterate using foreach*/