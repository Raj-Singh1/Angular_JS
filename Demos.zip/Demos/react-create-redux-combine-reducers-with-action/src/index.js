import React from 'react';

import ReactDOM from 'react-dom';


//import App from './App';

import {combineReducers,createStore} from 'redux';


function deptReducer(state=[],action){
return state;
}
function empReducer(state='',action){
	switch(action.type)
	{
	case 'addEmp':
		return action.payload;
	}
return state;
}

const allReducers=combineReducers({
department:deptReducer	,
employee:empReducer
});

const store=createStore(allReducers,{
department:[{deptName:"Admin"},{deptName:'engineering'}], employee:'ajay'
},
window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
);


const addEmpAction={
type:'addEmp',
payload:{
	 employee:'kings'	
	}
};
console.log(store.getState());

store.dispatch(addEmpAction);
const data=<h1>hi , hello</h1>;
ReactDOM.render(data
	, document.getElementById('root'));











