import React from 'react';

import ReactDOM from 'react-dom';


class Parent extends React.Component {
  render() {



	const buttons=React.Children.
		map(this.props.children,child=>(
	<i>
		{child}
	</i>
	));

	React.Children.forEach(this.props.children, child=>(
            console.log(child)     
        ));
	return(
		<div>count: {React.Children.count(this.props.children)}
		{buttons}
		{this.props.children}

		</div>
	);   
  }
}
export default Parent;


