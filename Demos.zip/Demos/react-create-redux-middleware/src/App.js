import React from 'react';

import ReactDOM from 'react-dom';


import Counter from './Counter';
import store from './storeReducer';
class App extends React.Component
{
	
	render(){
	return(
	<div>
		<Counter store={store}/>
	</div>
	);
	}
}

export default App;








