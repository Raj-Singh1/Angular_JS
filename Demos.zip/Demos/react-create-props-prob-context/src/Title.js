import React from 'react';

import ReactDOM from 'react-dom';

import ThemeContext from './ThemeContext';

class Title extends React.Component {
  render() {
    return (
      <ThemeContext.Consumer>
        {coloredTheme =>
          <div style={{ color: coloredTheme }}>
            Hello World
          </div>
        }
      </ThemeContext.Consumer>
    );
  }
}
export default Title;


