import React from 'react';

import ReactDOM from 'react-dom';


import { Link,Switch } from 'react-router-dom';

const Home = () => (<div><h1>Welcome home</h1><Link to='/about'>Go to about</Link></div>)

export default Home;








