import React from 'react';

import ReactDOM from 'react-dom';


import { Link,Switch } from 'react-router-dom';

const About = () => (<div><h1>About</h1><Link to='/'>Go home</Link></div>)

export default About;








