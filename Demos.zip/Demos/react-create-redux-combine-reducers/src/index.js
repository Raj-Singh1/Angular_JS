import React from 'react';

import ReactDOM from 'react-dom';


//import App from './App';

import {combineReducers,createStore} from 'redux';


function deptReducer(state=[],action){
return state;
}
function empReducer(state='',action){
return state;
}

const allReducers=combineReducers({
department:deptReducer	,
employee:empReducer
});

const store=createStore(allReducers,{
department:[{deptName:"Admin"},{deptName:'engineering'}], employee:'ajay'
},
window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
);

console.log(store.getState());
const data=<h1>hi , hello</h1>;
ReactDOM.render(data
	, document.getElementById('root'));











