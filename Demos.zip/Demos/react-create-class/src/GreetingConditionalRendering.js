import React from 'react';

import ReactDOM from 'react-dom';


class Greeting extends React.Component
{

}
export default Greeting;

