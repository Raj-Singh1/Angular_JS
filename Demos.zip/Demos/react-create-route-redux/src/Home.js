import React from 'react';

import ReactDOM from 'react-dom';


class Home extends React.Component {

render() {
		return(<h1>home</h1>);
	
	}
}
export default Home;


