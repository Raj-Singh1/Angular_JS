import { Component } from '@angular/core';
import { Employee } from './employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  employees:Employee[]=[
    {empId:1001,empName:'Rahul',empSal:9000,empDep:'java',empjoiningdate:'6/12/2014'},
    {empId:1002,empName:'Prodyut',empSal:9000,empDep:'c++',empjoiningdate:'7/12/2014'},
    {empId:1003,empName:'Nitin',empSal:9000,empDep:'c#',empjoiningdate:'8/12/2014'},
    {empId:1004,empName:'Pradosh',empSal:9000,empDep:'html',empjoiningdate:'9/12/2014'},
    {empId:1005,empName:'Rishabh',empSal:9000,empDep:'javascript',empjoiningdate:'1/12/2014'},
    {empId:1006,empName:'Umar',empSal:9000,empDep:'typescript',empjoiningdate:'4/12/2014'}
  ]
}
