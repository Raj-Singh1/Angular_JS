import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
 status:boolean=false;
 data:number=0;
  constructor() { }

  show1():void{
    this.status=!this.status;
  }
  show():void{
     this.data =1;

  }
  doget():void{
    this.data=2;
  }
  ngOnInit() {
  }

}
