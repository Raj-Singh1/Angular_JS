import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  pros:Product[]=[];
  pro : Product=new Product();
  constructor() { }

 
  

  ngOnInit() {
  }
  addPro(){

    this.pros.push(this.pro);
    console.log("Product added +"+JSON.stringify(this.pro));
    console.log(JSON.stringify(this.pros));
    this.pro = new Product();
  }
}
