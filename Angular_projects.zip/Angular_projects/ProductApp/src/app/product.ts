export class Product {
    proId:number;
    proName:string;
    proQty:number;
    constructor(values:Object={})
    {
        Object.assign(this,values);
    }
}
