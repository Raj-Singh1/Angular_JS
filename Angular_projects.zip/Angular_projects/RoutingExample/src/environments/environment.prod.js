"use strict";
exports.environment = {
    production: true
};
