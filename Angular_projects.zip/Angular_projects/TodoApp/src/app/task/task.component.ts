import { Component, OnInit } from '@angular/core';
import { Task } from '../task';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {

  //UI-component class - services - rest

  task: Task = new Task();
  

  constructor() { }

  ngOnInit() {
  }

  addTask(): void {


    console.log("task added " + JSON.stringify(this.task));
    
    this.task=new Task();

  }
}
