import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css'],
  providers: [EmployeeService]
})
export class EmpComponent implements OnInit {

  emps: Emp[] = null;
  emp: Emp = new Emp();

  constructor(private employeeservice: EmployeeService) {

  }
  addEmp(emp) {

    this.employeeservice.addEmp(emp);
    if (!emp.id) {
      this.employeeservice.addEmp(emp).subscribe((empData) => {this.employeeservice.getAllTask().subscribe((data) => this.emps = data)});
    }
    else {
      this.employeeservice.update(emp).subscribe((empData) => {this.employeeservice.getAllTask().subscribe((data) => this.emps = data)});
    }

    this.emp = new Emp();



    // if (!this.emp.id) {
    //   console.log("Employee added " + JSON.stringify(this.emp))
    //   this.employeeservice.addEmp(this.emp);
    //   this.employeeservice.getAllTask().subscribe((empData) => this.emps = empData); //over the component if we have to retrieve data we have to call subscribe() function.
    //   console.log(JSON.stringify(this.emps))
    //   this.emp = new Emp();
    // }
    // else {
    //   this.employeeservice.update(this.emp);
    //   this.employeeservice.getAllTask().subscribe((empData) => this.emps = empData);
    // }
  }

  remove(id: number): void {
    console.log("Details removed with ID " + id);

    this.employeeservice.remove(id).subscribe((empData) => {
      this.employeeservice.getAllTask().subscribe((data) => this.emps = data), (error) => {
        console.log(error);
      }
    });

  }

  update(e) {

    console.log("update entered");
    Object.assign(this.emp, e);


  }
  ngOnInit() {
    this.employeeservice.getAllTask().subscribe((empData) => this.emps = empData);
  }

}
