import { Component, OnInit, Input } from '@angular/core';
import { Emp } from '../emp';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  @Input()
  emps:Emp[]=[];
  emp:Emp=new Emp();
  constructor() { }

  ngOnInit() {
  }

}
