import { Component, OnInit,Output,EventEmitter } from '@angular/core';
import { Emp } from '../emp';



@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
emps:Emp[]=[];
emp:Emp=new Emp();
@Output()
add: EventEmitter<Emp>=new EventEmitter();

  constructor() { }

  ngOnInit() {
  }
addEmp()
{
  console.log("User added");
  this.add.emit(this.emp);
}
}
