export class Emp {

    id: number;
    empName: string;
    Salary: number;
    
    constructor(values: Object = {}) {
        (<any>Object).assign(this, values);
    }

}