import { Injectable } from '@angular/core';
import { Emp } from './emp';
import {Http,Response} from '@angular/http'
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map";
import "rxjs/add/operator/catch";
@Injectable()
export class EmployeeService {

  counter: number = 0;
  emp: Emp[] = [];
  constructor(private http:Http) { }
  addEmp(e: Emp):  Observable<Emp[]> {
   
    return this.http.post("http://localhost:3000/Emps",e).map((response:Response)=><Emp[]>response.json());
  }

  getAllTask(): Observable<Emp[]> {
    return this.http.get("http://localhost:3000/Emps").map((response:Response)=><Emp[]>response.json());
  }
  remove(id: number): Observable<Emp> {
    return this.http.delete("http://localhost:3000/Emps/"+id).map((response:Response)=><Emp>response.json()).catch(this.handleError);
 
  }
  update(e:Emp):Observable<Emp[]> {
 
    return this.http.put("http://localhost:3000/Emps/"+e.id,e).map((response:Response)=><Emp[]>response.json()).catch(this.handleError);
  }

  handleError(error:Response)
  {
    console.log(error);
    return Observable.throw(error);
  }
 
  
}
