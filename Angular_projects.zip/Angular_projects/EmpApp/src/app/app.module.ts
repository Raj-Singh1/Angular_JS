import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { }from '@angular/cli'
import { AppComponent } from './app.component';
import { EmpComponent } from './emp/emp.component';
import { FormsModule } from '@angular/forms';
import {HttpModule} from '@angular/http';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { DisplayComponent } from './display/display.component'

@NgModule({
  declarations: [
    AppComponent,
    EmpComponent,
    HeaderComponent,
    FooterComponent,
    DisplayComponent
  ],
  imports: [
    BrowserModule, FormsModule, HttpModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
