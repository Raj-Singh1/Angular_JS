function GetType(val) {
    return typeof (val);
}
var ename = "Abcd";
var one = 10;
document.write("Call Generics " + GetType(ename) + " " + GetType(one));
//class -generics
var GetNumber = (function () {
    function GetNumber() {
    }
    return GetNumber;
}());
var result = new GetNumber();
result.add = function (x, y) {
    return x + y;
};
document.write("Addition of 5+2" + result.add(5, 2));
