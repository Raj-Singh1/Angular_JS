export class Employee{
    empId:number;
    empName:string;
    
}